# CGC Plugin Library

This library provides types and functions for common tasks in CGC plugins.

## Usage
Import the library into your plugin with:
```
import cgcpluginlib as cpl

# e.g.
cpl.parse_args()
```